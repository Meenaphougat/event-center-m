Event Center Website
--------------------
This is a simple event center website with the following pages:
- Home
- Events
- Menu
- Location
- Contact Us

Technologies Used:
- HTML5
- CSS3

Features:
- Responsive Design
- Interactive Navigation Bar
- Contact Form with Validation
